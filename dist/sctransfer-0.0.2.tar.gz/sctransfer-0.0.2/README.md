# The supporting Python package of SAVER-X

This package is designed to be used by the R code of [SAVER-X](https://github.com/jingshuw/SAVERX).
It contains simplified code from the python [dca](http://github.com/theislab/dca) package and the new Python code for transfer learning.

One can also use this Python package for pre-training using public data. Instructions on pre-training will come out soon.

## Installation:

```
pip install sctransfer
```
The package only supports Python (>=3.5)

