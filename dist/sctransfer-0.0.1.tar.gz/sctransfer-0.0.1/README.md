# The supporting package for the Python code part of SAVER-X

This package should not be used alone. It is designed to be used internally by the R code of SAVER-X.
It contains simplified code from the python dca package and the new Python code for transfer learning.
